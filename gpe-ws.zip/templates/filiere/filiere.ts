export class Filiere {
    id: any;
                                codefiliere: string;
                                        libellefiliere: string;
                                        codenum: string;
                                        description: string;
                                        codeSigesr: string;
                    }
