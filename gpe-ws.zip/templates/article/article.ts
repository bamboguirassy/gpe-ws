export class Article {
    id: any;
                                titre: string;
                                        contenu: string;
                                        dateCreation: string;
                                        userCreation: string;
                                        publie: string;
                                        datePublication: string;
                                        userPublication: string;
                                        dateDesactivation: string;
                                        userDesactivation: string;
                                        photoName: string;
                                        photoPath: string;
                    }
