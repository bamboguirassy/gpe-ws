export class Classe {
    id: any;
                                codeclasse: string;
                                        libelleclasse: string;
                                        etat: string;
                    }
