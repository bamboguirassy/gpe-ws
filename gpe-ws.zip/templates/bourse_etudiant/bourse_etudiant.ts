export class BourseEtudiant {
    id: any;
                                prenoms: string;
                                        nom: string;
                                        dateNaissance: string;
                                        lieuNaissance: string;
                                        tauxBourse: string;
                                        montantBourse: string;
                                        mois: string;
                                        annee: string;
                    }
