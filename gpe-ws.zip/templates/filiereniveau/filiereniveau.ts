export class Filiereniveau {
    id: any;
            }
