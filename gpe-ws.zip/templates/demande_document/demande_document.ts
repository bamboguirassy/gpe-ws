export class DemandeDocument {
    id: any;
                                type: string;
                                        intitule: string;
                    }
