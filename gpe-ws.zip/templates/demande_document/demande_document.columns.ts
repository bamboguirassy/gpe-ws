const demande_documentColumns = [
            { header: 'Type', field: 'type', dataKey: 'type' },
            { header: 'Intitule', field: 'intitule', dataKey: 'intitule' },
        ];

const allowedDemandeDocumentFieldsForFilter = [
    'type',
    'intitule',
];

export { demande_documentColumns,allowedDemandeDocumentFieldsForFilter };
