export class AssistanceEmail {
    id: any;
                                typeAssistance: string;
                                        email: string;
                                        etat: string;
                                        destinationApp: string;
                    }
