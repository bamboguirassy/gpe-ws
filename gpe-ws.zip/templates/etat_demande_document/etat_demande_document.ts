export class EtatDemandeDocument {
    id: any;
                                libelle: string;
                                        description: string;
                                        codeCouleur: string;
                    }
