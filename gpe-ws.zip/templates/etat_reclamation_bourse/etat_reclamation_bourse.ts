export class EtatReclamationBourse {
    id: any;
                                libelle: string;
                                        codeCouleur: string;
                                        description: string;
                    }
