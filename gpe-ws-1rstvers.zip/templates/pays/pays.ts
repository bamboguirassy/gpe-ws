export class Pays {
    id: any;
                                code: string;
                                        alpha2: string;
                                        alpha3: string;
                                        nomEnGb: string;
                                        nomFrFr: string;
                                        nationalite: string;
                                        montantInscriptionLicence: string;
                                        montantInscriptionMaster: string;
                                        montantInscriptionDoctorat: string;
                    }
