const filiereniveauColumns = [
        ];

const allowedFiliereniveauFieldsForFilter = [
];

export { filiereniveauColumns,allowedFiliereniveauFieldsForFilter };
