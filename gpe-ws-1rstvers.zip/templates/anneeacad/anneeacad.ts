export class Anneeacad {
    id: any;
                                codeanneeacad: string;
                                        libelleanneeacad: string;
                                        encours: string;
                                        dateouvert: string;
                                        dateferm: string;
                                        nbreInscrits: string;
                    }
