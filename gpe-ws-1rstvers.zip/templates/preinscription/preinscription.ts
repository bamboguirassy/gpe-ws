export class Preinscription {
    id: any;
                                idfiliere: string;
                                        idanneeacad: string;
                                        idniveau: string;
                                        cni: string;
                                        idtypeadmission: string;
                                        ine: string;
                                        passage: string;
                                        prenometudiant: string;
                                        nometudiant: string;
                                        datenaiss: string;
                                        lieunaiss: string;
                                        email: string;
                                        tel: string;
                                        datenotif: string;
                                        datedelai: string;
                                        estinscrit: string;
                                        codeOperateur: string;
                                        datePaiement: string;
                                        numeroTransaction: string;
                                        montant: string;
                    }
