export class Regimeinscription {
    id: any;
                                coderegimeinscription: string;
                                        libelleregimeinscription: string;
                                        description: string;
                    }
