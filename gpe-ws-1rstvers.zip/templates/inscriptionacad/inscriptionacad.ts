export class Inscriptionacad {
    id: any;
                                dateinscacad: string;
                                        passage: string;
                                        etat: string;
                                        montantinscriptionacad: string;
                                        coutformation: string;
                                        numquittance: string;
                                        cartetiree: string;
                                        certificattire: string;
                                        valide: string;
                                        quitusBu: string;
                                        quitusSocial: string;
                                        quitusMedical: string;
                                        quitusComptabilite: string;
                                        quitusVieUniversitaire: string;
                                        universitepartenaire: string;
                                        sourcefinancement: string;
                                        coencadreur: string;
                                        premiereanneeinscription: string;
                                        datemodification: string;
                                        moyenneAnnuelle: string;
                                        totalCredit: string;
                                        creditCapitalise: string;
                                        decisionConseil: string;
                    }
