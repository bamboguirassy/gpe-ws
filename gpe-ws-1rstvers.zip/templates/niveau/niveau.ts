export class Niveau {
    id: any;
                                codeniveau: string;
                                        codeSigesr: string;
                                        libelleniveau: string;
                                        ddc: string;
                                        description: string;
                    }
