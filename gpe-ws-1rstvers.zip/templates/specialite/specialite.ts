export class Specialite {
    id: any;
                                codespecialite: string;
                                        libellespecialite: string;
                                        description: string;
                                        langueutilisee: string;
                                        typeaccreditation: string;
                                        codeSigesrSpecialite: string;
                    }
